import sys
from PyQt5 import QtGui, QtWidgets, uic, QtCore
from PyQt5.QtCore import pyqtSlot, Qt
from PyQt5 import QtOpenGL
from OpenGL.GL import *
from OpenGL.GLU import *
from OpenGL.GLUT import *

from viewer3DWidget import *


class Main(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = uic.loadUi('Window.ui')  # Cargamos .ui
        self.ui.setWindowFlags(Qt.WindowCloseButtonHint | Qt.WindowMinimizeButtonHint)
        self.viewer3D = viewer3DWidget(self)  # Llamamos la clase de OpenGl
        self.ui.OpenGLWorld.addWidget(self.viewer3D)
        self.ui.show()  # Mostramos ventana

        # Widgets
        self.ui.absisa.valueChanged.connect(self.absisa)
        self.ui.ordenada.valueChanged.connect(self.ordenada)
        self.ui.fondo.valueChanged.connect(self.fondo)
        self.ui.moverFigura.valueChanged.connect(self.translador)
        self.ui.moverCamara.valueChanged.connect(self.cambiarVista)

        self.ui.reinicio.clicked.connect(self.reiniciar)

        self.ui.figuras.currentIndexChanged.connect(self.cambiarFigura)

        self.ui.checkVistaC.stateChanged.connect(self.cambiarVista2)

    def absisa(self):
        self.viewer3D.angx = self.ui.absisa.value()  # Rotar en angulo x
        self.viewer3D.updateGL()

    def ordenada(self):
        self.viewer3D.angy = self.ui.ordenada.value()  # Rotar en angulo y
        self.viewer3D.updateGL()

    def fondo(self):
        self.viewer3D.angz = self.ui.fondo.value()  # Rotar en angulo z
        self.viewer3D.updateGL()

    def translador(self):
        self.viewer3D.posX = self.ui.moverFigura.value()
        self.viewer3D.updateGL()

    def reiniciar(self):
        self.viewer3D.angx = 0
        self.viewer3D.angy = 0
        self.viewer3D.angz = 0
        self.viewer3D.posX = 0
        self.viewer3D.posvistaX = 1 / 3
        self.viewer3D.posvistaY = 1 / 3
        self.viewer3D.vistaX = 0
        self.viewer3D.vistaY = 0
        self.viewer3D.updateGL()

    def cambiarFigura(self): # Cambiamos segun combobox la figura a mostrar
        self.viewer3D.changeFig = self.ui.figuras.currentText()
        self.viewer3D.updateGL()

    def cambiarVista(self): # con la Slider de moverCamara cambiamos la posicion de la camara
        self.viewer3D.posvistaX = self.ui.moverCamara.value()
        self.viewer3D.posvistaY = self.ui.moverCamara.value()
        self.viewer3D.updateGL()

    def cambiarVista2(self): # Segun el valor de checkBox utilizamos un mousetracking para cambiar hacia donde vera
        self.viewer3D.moverCamara = self.ui.checkVistaC.checkState()
        self.viewer3D.updateGL()


if __name__ == '__main__': # Como este es el main lo hacemos funcionar con la condicional
    app = QtWidgets.QApplication(sys.argv)
    ventana = Main()
    sys.exit(app.exec_())
