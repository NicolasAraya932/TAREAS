from OpenGL.GL import *
from OpenGL.GLU import *

from NoteObject import *


def CubeMesh():
    glBegin(GL_QUADS)
    for face in cube_faces_vector4:
        # Damos color a cada una de las caras con un vector
        x = 0
        for vertex in face:
            x += 1
            glColor3fv(colors[x])
            glVertex3fv(cube_verticies_vector3[vertex])
    glEnd()

    glBegin(GL_LINES)
    for edge in cube_edges_vector2:
        for vertex in edge:
            glVertex3fv(cube_verticies_vector3[vertex])
    glEnd()


def Note():
    # Definimos segun valores de vertices, caras y lados al notebook
    glBegin(GL_QUADS)
    for face in OBJ_Faces:
        for vertex in face:
            glColor3f(0.3, 0.2, 0.1)
            glVertex3fv(OBJ_vertices[vertex])
    glEnd()

    glBegin(GL_LINES)
    for edge in OBJ_Edges:
        for vertex in edge:
            glColor3f(1, 1, 1)
            glVertex3fv(OBJ_vertices[vertex])
    glEnd()
