from OpenGL.GL import *
from OpenGL.GLU import *

from Mesh import *

from main import *


class viewer3DWidget(QtOpenGL.QGLWidget):
    max_xyz = 5.0 # Dimensiones del escenario

    def __init__(self, parent=None):
        QtOpenGL.QGLWidget.__init__(self, parent)
        self.angx, self.angy, self.angz = 0, 0, 0 # Angulos iniciales

        self.posX = 0

        self.posvistaX = 1 / 3 # Posicion de la camara en el espacio
        self.posvistaY = 1 / 3

        self.vistaX = 0 # Hacia donde ve la camara
        self.vistaY = 0

        self.moverCamara = False # bool para mouse tracker

        self.changeFig = "Notebook" # Contenido de combobox
        self.setMouseTracking(True) # Permitir tracking del mouse

    def paintGL(self):
        glMatrixMode(GL_MODELVIEW)
        glLoadIdentity()
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        glEnable(GL_DEPTH_TEST)
        glEnable(GL_LIGHT0)
        glLightfv(GL_LIGHT0, GL_AMBIENT, [0.5, 0.5, 0.5, 1])
        glLightfv(GL_LIGHT0, GL_DIFFUSE, [1.0, 1.0, 1.0, 1])
        glLightfv(GL_LIGHT0, GL_POSITION, [1, -1, 1, 0])
        self.dibujar() # Cargamos figuras y otrosa
        glFlush()

    def resizeGL(self, widthInPixels, heightInPixels):
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        glOrtho(-self.max_xyz, self.max_xyz, -self.max_xyz, self.max_xyz, -self.max_xyz, self.max_xyz)
        # glOrtho tamaño de la pantalla
        glViewport(0, 0, widthInPixels, heightInPixels)  # area visible
        gluLookAt(self.vistaX, self.vistaY, 0, self.posvistaX, self.posvistaY, 1, 1, 1, 1)  # apuntar camara, posicion camara

    def initializeGL(self):
        glClearColor(0.0, 0.0, 0.0, 1.0)
        glClearDepth(1.0)

    def dibujar(self): # Agregamos transformaciones para la figura
        glRotatef(self.angx, 1.0, 0.0, 0.0)
        glRotatef(self.angy, 0.0, 1.0, 0.0)
        glRotatef(self.angz, 0.0, 0.0, 1.0)
        glTranslatef(self.posX, 0, 0)
        gluLookAt(self.vistaX, self.vistaY, 0, self.posvistaX, self.posvistaY, 1, 1, 1, 1)
        if self.changeFig == "Notebook": # Segun combobox cambiamos la figura
            Note()
        elif self.changeFig == "CuboBrillante":
            CubeMesh()

    ##################BONUS##################
    def mouseMoveEvent(self, event) -> None: # si el mouse se mueve en el layour la camara observara en un lugar distinto
        if self.moverCamara:
            self.vistaX = event.x()/350
            self.vistaY = event.y()/200
            self.updateGL()

